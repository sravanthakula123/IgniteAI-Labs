"use client"

import { createContext, useContext, useState, useCallback, type ReactNode } from "react"

interface User {
  email: string
  name: string
}

interface AuthContextType {
  user: User | null
  isAuthenticated: boolean
  login: (email: string, password: string) => { success: boolean; error?: string }
  logout: () => void
}

const DUMMY_USERS = [
  { email: "admin@grammacare.com", password: "admin123", name: "Dr. Admin" },
  { email: "doctor@grammacare.com", password: "doctor123", name: "Dr. Smith" },
  { email: "patient@grammacare.com", password: "patient123", name: "John Doe" },
  { email: "demo@grammacare.com", password: "demo123", name: "Demo User" },
]

const AuthContext = createContext<AuthContextType | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null)

  const login = useCallback((email: string, password: string) => {
    const found = DUMMY_USERS.find(
      (u) => u.email.toLowerCase() === email.toLowerCase() && u.password === password
    )
    if (found) {
      setUser({ email: found.email, name: found.name })
      return { success: true }
    }
    return { success: false, error: "Invalid email or password. Please try again." }
  }, [])

  const logout = useCallback(() => {
    setUser(null)
  }, [])

  return (
    <AuthContext.Provider value={{ user, isAuthenticated: !!user, login, logout }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider")
  }
  return context
}
