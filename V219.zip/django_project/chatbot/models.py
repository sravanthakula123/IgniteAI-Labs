from django.db import models


class ChatSession(models.Model):
    """Stores a chat consultation session."""
    session_id = models.CharField(max_length=100, unique=True)
    patient_name = models.CharField(max_length=200)
    patient_email = models.EmailField()
    primary_symptom = models.CharField(max_length=200, blank=True)
    diagnosis = models.TextField(blank=True)
    severity_level = models.CharField(max_length=20, blank=True)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)

    def __str__(self):
        return f"{self.patient_name} - {self.primary_symptom or 'No symptom'} ({self.created_at})"

    class Meta:
        ordering = ['-created_at']


class ChatMessage(models.Model):
    """Stores individual chat messages within a session."""
    ROLE_CHOICES = [
        ('user', 'User'),
        ('assistant', 'Assistant'),
        ('system', 'System'),
    ]

    session = models.ForeignKey(ChatSession, on_delete=models.CASCADE, related_name='messages')
    role = models.CharField(max_length=10, choices=ROLE_CHOICES)
    content = models.TextField()
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"[{self.role}] {self.content[:50]}..."

    class Meta:
        ordering = ['timestamp']
