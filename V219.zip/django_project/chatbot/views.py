"""
GrammaCare AI - Django Views
All original backend logic and functions are preserved from the CLI version.
The views act as API endpoints that wrap the existing ML + Gemini logic.
"""

import re
import os
import csv
import json
import warnings
import requests
import numpy as np
import pandas as pd

from django.http import JsonResponse
from django.views.decorators.csrf import csrf_exempt
from django.views.decorators.http import require_http_method

from sklearn import preprocessing
from sklearn.tree import DecisionTreeClassifier, _tree
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.svm import SVC

warnings.filterwarnings("ignore")

AI_NAME = "GrammaCare AI"

# ─────────────────────────────────────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────────────────────────────────────
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY", "AIzaSyC-MqWlLFbD96XD1QHXqF879_2vD6ivtGg")
GEMINI_MODEL = "gemini-2.5-flash"

GEMINI_API_URL = (
    f"https://generativelanguage.googleapis.com/v1beta/models/"
    f"{GEMINI_MODEL}:generateContent"
)

SYSTEM_INSTRUCTION = f"""
You are {AI_NAME} — a compassionate, experienced virtual healthcare assistant.
Your communication style:
  • Warm, empathetic, and reassuring — never robotic or clinical
  • Use simple, easy-to-understand language (no heavy medical jargon)
  • Always address the patient by their name
  • Structure your responses clearly but conversationally — like a caring doctor would
  • Always remind the patient that you are an AI and they should consult a real doctor for serious concerns
  • Never be alarmist — be honest but kind and supportive
  • Your name is {AI_NAME} — refer to yourself by this name when needed
"""

# ─────────────────────────────────────────────────────────────────────────────
# DUMMY USERS FOR LOGIN
# ─────────────────────────────────────────────────────────────────────────────
DUMMY_USERS = [
    {"email": "admin@grammacare.com", "password": "admin123", "name": "Dr. Admin"},
    {"email": "doctor@grammacare.com", "password": "doctor123", "name": "Dr. Smith"},
    {"email": "patient@grammacare.com", "password": "patient123", "name": "John Doe"},
    {"email": "demo@grammacare.com", "password": "demo123", "name": "Demo User"},
]

# ─────────────────────────────────────────────────────────────────────────────
# DATA DIRECTORY - Adjust path relative to Django project root
# ─────────────────────────────────────────────────────────────────────────────
DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'Data')
MASTER_DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), 'MasterData')


# ─────────────────────────────────────────────────────────────────────────────
# GEMINI CLIENT (pure REST API — no SDK needed!) [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def ask_gemini(prompt: str, patient_name: str = "") -> str:
    """Call Gemini REST API directly — no SDK required."""
    try:
        full_prompt = f"Patient name: {patient_name}\n\n" + prompt if patient_name else prompt
        payload = {
            "system_instruction": {
                "parts": [{"text": SYSTEM_INSTRUCTION}]
            },
            "contents": [
                {"role": "user", "parts": [{"text": full_prompt}]}
            ],
            "generationConfig": {
                "temperature": 0.7,
                "maxOutputTokens": 1024,
            }
        }
        response = requests.post(
            GEMINI_API_URL,
            headers={"Content-Type": "application/json"},
            params={"key": GEMINI_API_KEY},
            data=json.dumps(payload),
            timeout=30,
        )
        result = response.json()
        return result["candidates"][0]["content"]["parts"][0]["text"].strip()
    except Exception as e:
        return f"[{AI_NAME} temporarily unavailable: {e}]"


# ─────────────────────────────────────────────────────────────────────────────
# LOCATION DETECTION [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def get_user_location() -> dict:
    """
    Detects user's location automatically using their IP address.
    Uses ip-api.com (completely free, no API key required).
    """
    try:
        response = requests.get(
            "http://ip-api.com/json/",
            timeout=8,
            params={"fields": "status,city,regionName,country,lat,lon,timezone,isp,query"}
        )
        data = response.json()
        if data.get("status") == "success":
            return {
                "city": data.get("city", "Unknown City"),
                "region": data.get("regionName", ""),
                "country": data.get("country", ""),
                "lat": data.get("lat"),
                "lon": data.get("lon"),
                "timezone": data.get("timezone", ""),
                "ip": data.get("query", ""),
                "detected": True,
            }
    except Exception:
        pass
    return {"detected": False, "city": None, "region": None, "country": None}


# ─────────────────────────────────────────────────────────────────────────────
# GEMINI-POWERED HOSPITAL FINDER [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def gemini_find_hospitals(disease: str, location: dict, name: str) -> str:
    """Ask Gemini to suggest nearby hospitals/specialists."""
    if location.get("detected"):
        city = location["city"]
        region = location["region"]
        country = location["country"]
        loc_str = f"{city}, {region}, {country}"
    else:
        loc_str = "their current location (location could not be auto-detected)"

    prompt = f"""
The patient {name} has been diagnosed with: {disease}
Their detected location is: {loc_str}

As {AI_NAME}, do the following:

1. Identify the best type of specialist/hospital department they should visit for {disease}
2. Suggest 4-5 well-known, reputable hospitals or healthcare chains in or near {loc_str}
   that would be appropriate for treating {disease}.
   Format each as:
   [Hospital Name]
      Location: Area/Location in {city if location.get("detected") else "their city"}
      Department to visit: [relevant department]
      Why this hospital: [one short reason]

3. Add a practical tip at the end:
   - What to carry for the appointment (ID, reports, etc.)
   - Best time to visit (morning preferred for most hospitals)
   - Whether to call ahead for an appointment

4. If the location seems incorrect or unavailable, still give general advice for finding hospitals.

Keep the tone warm and reassuring as {AI_NAME}. Address the patient by name.
"""
    return ask_gemini(prompt, name)


# ─────────────────────────────────────────────────────────────────────────────
# ML MODEL SETUP [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
_ml_cache = {}


def load_ml_models():
    """Load and cache ML models."""
    if 'models' in _ml_cache:
        return _ml_cache['models']

    training_path = os.path.join(DATA_DIR, 'Training.csv')
    testing_path = os.path.join(DATA_DIR, 'Testing.csv')

    if not os.path.exists(training_path):
        return None

    training = pd.read_csv(training_path)
    testing = pd.read_csv(testing_path)

    cols = training.columns[:-1]
    x = training[cols]
    y = training['prognosis']

    le = preprocessing.LabelEncoder()
    le.fit(y)
    y_enc = le.transform(y)

    reduced_data = training.groupby('prognosis').max()

    x_train, x_test, y_train, y_test = train_test_split(
        x, y_enc, test_size=0.33, random_state=42
    )

    clf = DecisionTreeClassifier().fit(x_train, y_train)
    svm = SVC()
    svm.fit(x_train, y_train)

    symptoms_dict = {symptom: idx for idx, symptom in enumerate(cols)}

    result = (clf, svm, le, cols, reduced_data, symptoms_dict)
    _ml_cache['models'] = result
    return result


# ─────────────────────────────────────────────────────────────────────────────
# MASTER DATA LOADERS [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def load_master_data():
    """Load severity, description, and precaution data."""
    severity_dict = {}
    description_dict = {}
    precaution_dict = {}

    severity_path = os.path.join(MASTER_DATA_DIR, 'symptom_severity.csv')
    description_path = os.path.join(MASTER_DATA_DIR, 'symptom_Description.csv')
    precaution_path = os.path.join(MASTER_DATA_DIR, 'symptom_precaution.csv')

    if os.path.exists(severity_path):
        with open(severity_path) as f:
            for row in csv.reader(f):
                try:
                    severity_dict[row[0]] = int(row[1])
                except Exception:
                    pass

    if os.path.exists(description_path):
        with open(description_path) as f:
            for row in csv.reader(f):
                if len(row) >= 2:
                    description_dict[row[0]] = row[1]

    if os.path.exists(precaution_path):
        with open(precaution_path) as f:
            for row in csv.reader(f):
                if len(row) >= 5:
                    precaution_dict[row[0]] = [row[1], row[2], row[3], row[4]]

    return severity_dict, description_dict, precaution_dict


# ─────────────────────────────────────────────────────────────────────────────
# SEVERITY CALCULATOR [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def calculate_severity_score(symptoms: list, days: int, severity_dict: dict) -> tuple:
    """Returns (score, is_severe, level_label)."""
    if not symptoms:
        return 0, False, "Unknown"
    total = sum(severity_dict.get(s, 0) for s in symptoms)
    score = (total * days) / (len(symptoms) + 1)
    if score > 13:
        return score, True, "High"
    elif score > 7:
        return score, False, "Moderate"
    else:
        return score, False, "Low"


# ─────────────────────────────────────────────────────────────────────────────
# SECONDARY PREDICTION [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def sec_predict(symptoms_exp: list, cols, le) -> str:
    training_path = os.path.join(DATA_DIR, 'Training.csv')
    df = pd.read_csv(training_path)
    X = df.iloc[:, :-1]
    y = df['prognosis']
    x_tr, _, y_tr, _ = train_test_split(X, y, test_size=0.3, random_state=20)
    clf2 = DecisionTreeClassifier().fit(x_tr, y_tr)
    sym_dict = {s: i for i, s in enumerate(X.columns)}

    vec = np.zeros(len(sym_dict))
    for s in symptoms_exp:
        if s in sym_dict:
            vec[sym_dict[s]] = 1
    return clf2.predict([vec])[0]


# ─────────────────────────────────────────────────────────────────────────────
# PATTERN MATCHING [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def check_pattern(dis_list, inp):
    inp = inp.replace(' ', '_')
    try:
        regexp = re.compile(inp, re.IGNORECASE)
        pred_list = [item for item in dis_list if regexp.search(item)]
    except re.error:
        pred_list = []
    return (1, pred_list) if pred_list else (0, [])


# ─────────────────────────────────────────────────────────────────────────────
# DECISION TREE TRAVERSAL [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def traverse_tree(clf, feature_names, disease_input):
    """Traverse Decision Tree and return (disease_list, related_symptoms, symptoms_present)."""
    tree_ = clf.tree_
    feature_name = [
        feature_names[i] if i != _tree.TREE_UNDEFINED else "undefined!"
        for i in tree_.feature
    ]
    symptoms_present = []

    training_path = os.path.join(DATA_DIR, 'Training.csv')
    training = pd.read_csv(training_path)
    reduced_data = training.groupby('prognosis').max()
    le_temp = preprocessing.LabelEncoder()
    le_temp.fit(training['prognosis'])

    def decode_disease(node_val):
        val = node_val[0].nonzero()
        return list(map(lambda x: x.strip(), list(le_temp.inverse_transform(val[0]))))

    result = {}

    def recurse(node):
        if tree_.feature[node] != _tree.TREE_UNDEFINED:
            name = feature_name[node]
            threshold = tree_.threshold[node]
            val = 1 if name == disease_input else 0
            if val <= threshold:
                recurse(tree_.children_left[node])
            else:
                symptoms_present.append(name)
                recurse(tree_.children_right[node])
        else:
            present_disease = decode_disease(tree_.value[node])
            red_cols = reduced_data.columns
            symptoms_given = red_cols[reduced_data.loc[present_disease].values[0].nonzero()]
            result['disease'] = present_disease
            result['symptoms'] = symptoms_given

    recurse(0)
    return result.get('disease', []), result.get('symptoms', []), symptoms_present


# ─────────────────────────────────────────────────────────────────────────────
# GEMINI RESPONSE GENERATORS [PRESERVED FROM ORIGINAL]
# ─────────────────────────────────────────────────────────────────────────────
def gemini_greeting(name: str) -> str:
    return ask_gemini(f"""
Give a warm, friendly greeting to the patient named {name} as {AI_NAME}.
Welcome them to the health consultation. Tell them they can describe their main symptom
and you'll guide them through the rest. Keep it to 3-4 sentences. Be warm and reassuring.
""", name)


def gemini_diagnosis_response(
    name, disease, second_disease, description, second_description,
    symptoms_reported, severity_level, severity_score, days, precautions
) -> str:
    same = (disease == second_disease)
    return ask_gemini(f"""
You are {AI_NAME} giving a diagnosis summary to patient {name}.

Primary diagnosis  : {disease}
Secondary diagnosis: {"Same as primary — both models agree, high confidence!" if same else second_disease}
Disease description: {description}
{"Alternative description: " + second_description if not same else ""}

Symptoms the patient reported: {', '.join(symptoms_reported) if symptoms_reported else 'As described'}
Duration  : {days} day(s)
Severity  : {severity_level} (computed score: {severity_score:.1f}/20)
Precautions from database: {', '.join(precautions)}

Write a warm, doctor-patient style diagnosis report covering:
1. A reassuring opening addressing {name} by name
2. What they may have — explained in very simple, everyday language
3. What this condition means for their daily life
4. Severity level explained clearly
5. Recommended precautions — rephrase the database precautions warmly
6. A closing note reminding them {AI_NAME} is an AI and encouraging them to see a real doctor

Use light formatting — bullet points only for precautions. Keep tone warm and human.
""", name)


def gemini_otc_recommendations(disease: str, severity_level: str, name: str) -> str:
    return ask_gemini(f"""
Patient {name} has been tentatively diagnosed with: {disease}
Severity: {severity_level}

As {AI_NAME}, recommend appropriate Over-The-Counter (OTC) medications and home remedies.
Format your response clearly as:

OTC Medications:
   — List 2-3 specific OTC drug names with brief usage note

Home Remedies:
   — List 2-3 effective, practical home remedies

When to Stop Self-Medicating:
   — One clear sentence about when they MUST see a real doctor instead

End with a short disclaimer reminding {name} to consult a pharmacist or doctor before starting any medication.
""", name)


def gemini_farewell(name: str, disease: str) -> str:
    return ask_gemini(f"""
Give a warm goodbye message as {AI_NAME} to patient {name} who consulted about {disease}.
Wish them a speedy recovery, remind them to follow the precautions,
and encourage them to visit a real doctor. Keep it to 2-3 sentences. Warm and hopeful.
""", name)


# ═══════════════════════════════════════════════════════════════════════════════
# API VIEWS
# ═══════════════════════════════════════════════════════════════════════════════

@csrf_exempt
@require_http_method(["POST"])
def login_view(request):
    """Handle user login with dummy credentials."""
    try:
        data = json.loads(request.body)
        email = data.get("email", "").strip().lower()
        password = data.get("password", "").strip()

        for user in DUMMY_USERS:
            if user["email"].lower() == email and user["password"] == password:
                request.session["user"] = {
                    "email": user["email"],
                    "name": user["name"],
                }
                return JsonResponse({
                    "success": True,
                    "user": {"email": user["email"], "name": user["name"]},
                })

        return JsonResponse({
            "success": False,
            "error": "Invalid email or password. Please try again.",
        }, status=401)

    except Exception as e:
        return JsonResponse({"success": False, "error": str(e)}, status=400)


@csrf_exempt
@require_http_method(["POST"])
def logout_view(request):
    """Handle user logout."""
    request.session.flush()
    return JsonResponse({"success": True})


@csrf_exempt
@require_http_method(["GET"])
def user_view(request):
    """Get current logged-in user."""
    user = request.session.get("user")
    if user:
        return JsonResponse({"authenticated": True, "user": user})
    return JsonResponse({"authenticated": False}, status=401)


@csrf_exempt
@require_http_method(["POST"])
def chat_view(request):
    """
    Main chat API endpoint. Handles all conversation actions.
    Preserves all original backend logic and functions.
    """
    try:
        data = json.loads(request.body)
        action = data.get("action")
        patient_name = data.get("patientName", "Friend")
        extra = data.get("data", {})

        if action == "greeting":
            message = gemini_greeting(patient_name)
            return JsonResponse({"message": message})

        elif action == "match_symptom":
            symptom_input = data.get("symptom", "")

            # Try loading ML model columns for accurate symptom matching
            models = load_ml_models()
            if models:
                clf, svm, le, cols, reduced_data, symptoms_dict = models
                chk_dis = list(cols)
            else:
                # Fallback to hardcoded symptom list if CSV files aren't available
                chk_dis = _get_fallback_symptom_list()

            conf, matches = check_pattern(chk_dis, symptom_input)
            return JsonResponse({
                "matches": [
                    {
                        "name": m,
                        "display": m.replace("_", " ").title(),
                    }
                    for m in matches
                ]
            })

        elif action == "diagnose":
            selected_symptom = extra.get("selectedSymptom", "")
            days = int(extra.get("days", 1))
            confirmed_symptoms = extra.get("confirmedSymptoms", [])

            models = load_ml_models()
            if models:
                clf, svm, le, cols, reduced_data, symptoms_dict = models
                severity_dict, description_dict, precaution_dict = load_master_data()

                # Decision Tree Traversal [PRESERVED]
                present_disease, symptoms_given, symptoms_present = traverse_tree(
                    clf, cols, selected_symptom
                )

                if not present_disease:
                    # Fallback to Gemini for diagnosis
                    all_symptoms = [selected_symptom] + confirmed_symptoms
                    diagnosis = ask_gemini(
                        f"Patient {patient_name} reports: {', '.join(s.replace('_', ' ') for s in all_symptoms)} for {days} days. Provide diagnosis.",
                        patient_name
                    )
                    return JsonResponse({"diagnosis": diagnosis})

                # Secondary Prediction [PRESERVED]
                all_symptoms = list(set(symptoms_present + confirmed_symptoms))
                second_disease = sec_predict(all_symptoms, cols, le)

                # Severity Calculation [PRESERVED]
                score, is_severe, severity_level = calculate_severity_score(
                    all_symptoms, days, severity_dict
                )

                # Descriptions & Precautions [PRESERVED]
                primary_desc = description_dict.get(present_disease[0], "No description available.")
                secondary_desc = description_dict.get(second_disease, "No description available.")
                precautions = precaution_dict.get(present_disease[0], [])

                # Gemini Diagnosis Report [PRESERVED]
                diagnosis = gemini_diagnosis_response(
                    name=patient_name,
                    disease=present_disease[0],
                    second_disease=second_disease,
                    description=primary_desc,
                    second_description=secondary_desc,
                    symptoms_reported=all_symptoms,
                    severity_level=severity_level,
                    severity_score=score,
                    days=days,
                    precautions=precautions,
                )
                return JsonResponse({
                    "diagnosis": diagnosis,
                    "disease": present_disease[0],
                    "secondDisease": second_disease,
                    "severityLevel": severity_level,
                    "severityScore": score,
                    "isSevere": is_severe,
                    "precautions": precautions,
                })
            else:
                # Fallback: Use Gemini only when ML models unavailable
                all_symptoms = [selected_symptom] + confirmed_symptoms
                diagnosis = ask_gemini(
                    f"Patient {patient_name} reports: {', '.join(s.replace('_', ' ') for s in all_symptoms)} for {days} days. Provide a comprehensive diagnosis.",
                    patient_name
                )
                return JsonResponse({"diagnosis": diagnosis})

        elif action == "followup_symptoms":
            selected_symptom = extra.get("selectedSymptom", "")
            models = load_ml_models()
            if models:
                clf, svm, le, cols, reduced_data, symptoms_dict = models
                present_disease, symptoms_given, symptoms_present = traverse_tree(
                    clf, cols, selected_symptom
                )
                followup = [
                    {
                        "name": s,
                        "display": s.replace("_", " ").title(),
                    }
                    for s in list(symptoms_given)[:8]
                ]
                return JsonResponse({"followupSymptoms": followup})
            return JsonResponse({"followupSymptoms": []})

        elif action == "otc_recommendations":
            disease = extra.get("disease", "")
            severity_level = extra.get("severityLevel", "Moderate")
            message = gemini_otc_recommendations(disease, severity_level, patient_name)
            return JsonResponse({"message": message})

        elif action == "find_hospitals":
            disease = extra.get("disease", "")
            location = get_user_location()
            message = gemini_find_hospitals(disease, location, patient_name)
            return JsonResponse({"message": message, "location": location})

        elif action == "farewell":
            disease = extra.get("disease", "their health concern")
            message = gemini_farewell(patient_name, disease)
            return JsonResponse({"message": message})

        elif action == "free_chat":
            user_message = extra.get("message", "")
            message = ask_gemini(
                f'The patient {patient_name} says: "{user_message}"\n\n'
                f'As {AI_NAME}, respond helpfully. If health-related, provide guidance. '
                f'Keep it conversational and warm.',
                patient_name
            )
            return JsonResponse({"message": message})

        else:
            return JsonResponse({"error": "Unknown action"}, status=400)

    except Exception as e:
        return JsonResponse({"error": str(e)}, status=500)


def _get_fallback_symptom_list():
    """Fallback symptom list when CSV data isn't available."""
    return [
        "itching", "skin_rash", "nodal_skin_eruptions", "continuous_sneezing",
        "shivering", "chills", "joint_pain", "stomach_pain", "acidity",
        "ulcers_on_tongue", "muscle_wasting", "vomiting", "burning_micturition",
        "spotting_urination", "fatigue", "weight_gain", "anxiety",
        "cold_hands_and_feets", "mood_swings", "weight_loss", "restlessness",
        "lethargy", "patches_in_throat", "irregular_sugar_level", "cough",
        "high_fever", "sunken_eyes", "breathlessness", "sweating", "dehydration",
        "indigestion", "headache", "yellowish_skin", "dark_urine", "nausea",
        "loss_of_appetite", "pain_behind_the_eyes", "back_pain", "constipation",
        "abdominal_pain", "diarrhoea", "mild_fever", "yellow_urine",
        "yellowing_of_eyes", "acute_liver_failure", "fluid_overload",
        "swelling_of_stomach", "swelled_lymph_nodes", "malaise",
        "blurred_and_distorted_vision", "phlegm", "throat_irritation",
        "redness_of_eyes", "sinus_pressure", "runny_nose", "congestion",
        "chest_pain", "weakness_in_limbs", "fast_heart_rate",
        "pain_during_bowel_movements", "pain_in_anal_region", "bloody_stool",
        "irritation_in_anus", "neck_pain", "dizziness", "cramps", "bruising",
        "obesity", "swollen_legs", "swollen_blood_vessels", "puffy_face_and_eyes",
        "enlarged_thyroid", "brittle_nails", "swollen_extremeties",
        "excessive_hunger", "drying_and_tingling_lips", "slurred_speech",
        "knee_pain", "hip_joint_pain", "muscle_weakness", "stiff_neck",
        "swelling_joints", "movement_stiffness", "spinning_movements",
        "loss_of_balance", "unsteadiness", "weakness_of_one_body_side",
        "loss_of_smell", "bladder_discomfort", "foul_smell_of_urine",
        "continuous_feel_of_urine", "passage_of_gases", "internal_itching",
        "depression", "irritability", "muscle_pain", "altered_sensorium",
        "red_spots_over_body", "belly_pain", "abnormal_menstruation",
        "dischromic_patches", "watering_from_eyes", "increased_appetite",
        "polyuria", "family_history", "mucoid_sputum", "rusty_sputum",
        "lack_of_concentration", "visual_disturbances", "coma",
        "stomach_bleeding", "distention_of_abdomen",
        "history_of_alcohol_consumption", "blood_in_sputum",
        "prominent_veins_on_calf", "palpitations", "painful_walking",
        "pus_filled_pimples", "blackheads", "scurring", "skin_peeling",
        "silver_like_dusting", "small_dents_in_nails", "inflammatory_nails",
        "blister", "red_sore_around_nose", "yellow_crust_ooze",
    ]
